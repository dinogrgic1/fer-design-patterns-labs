void* myfactory(char const* libname, char const* ctorarg, _Bool heap);
