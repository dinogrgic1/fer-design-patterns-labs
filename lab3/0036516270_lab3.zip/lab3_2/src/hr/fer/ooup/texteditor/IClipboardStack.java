package hr.fer.ooup.texteditor;

public interface IClipboardStack {
    void updateClipboard();
}
