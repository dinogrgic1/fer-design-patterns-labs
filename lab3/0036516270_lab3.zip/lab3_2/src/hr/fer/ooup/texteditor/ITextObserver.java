package hr.fer.ooup.texteditor;

public interface ITextObserver {
    void updateText();
}
