package hr.fer.ooup.texteditor;

public interface IEditAction {
    public void execute_do();
    public void execute_undo();
}
