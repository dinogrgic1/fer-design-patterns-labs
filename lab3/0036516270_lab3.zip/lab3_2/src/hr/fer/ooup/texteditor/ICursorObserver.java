package hr.fer.ooup.texteditor;

public interface ICursorObserver {
    void updateCursorLocation();
}
