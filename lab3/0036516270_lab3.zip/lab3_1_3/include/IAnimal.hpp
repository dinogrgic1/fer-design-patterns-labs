class IAnimal
{
public:
    virtual char const *name() = 0;
    virtual char const *greet() = 0;
    virtual char const *menu() = 0;
};